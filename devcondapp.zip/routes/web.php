<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/symbolic', function (){
    $links = [  "shortcut" => base_path('public_html\storage'), "target" => base_path('storage/app/public')];
    try{
        symlink($links['target'], $links['shortcut']);
        echo "link criado com sucesso!";
    }catch (Exception $e){
        echo "Erro ".$e->getCode()." em ".$e->getFile()." na linha ".$e->getLine()." criar link simbólico: " .
            $e->getMessage()."<br>";
    }
});
