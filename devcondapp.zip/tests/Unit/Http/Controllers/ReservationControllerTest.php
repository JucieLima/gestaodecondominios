<?php

namespace Http\Controllers;

use App\Http\Controllers\ReservationController;
use PHPUnit\Framework\TestCase;

class ReservationControllerTest extends TestCase
{

    public function testSetReservation()
    {

    }
}
